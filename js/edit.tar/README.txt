#1)Files to be edited: 
	editplace.js 
	example.php
	edit.php

#2) The variable "url", declared in the top of "editplace.js" file, defines the server side file, which is called after the save button is pressed

#3) Make sure you include "prototype.js", "editinplace.js" on the top if the HTML file

#4) Add onLoad= "init()"  in BODY tag.

#5) I have used text file to read and store the text, but you can also use XML or Database to do the same.